import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Scanner;
public class Main {


    public static void main(String[] args) throws ParseException {


        Scanner sc = new Scanner(System.in);

        System.out.println("Enter your date of birth (dd-MM-yyyy): ");
        String dob = sc.next();


        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date date = formatter.parse(dob);


        Instant instant = date.toInstant();
        ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
        LocalDate givenDate = zone.toLocalDate();


        Period period = Period.between(givenDate, LocalDate.now());

        System.out.print(period.getYears() + " years " + period.getMonths() + " and " + period.getDays() + " days");

        int id;
        String name;
        float salary;
        Scanner s=new Scanner(System.in);

        System.out.println("\n Enter Employee  name:");
        name = s.nextLine(); //taking string input

        System.out.println("Enter Employee Id:");
        id = s.nextInt(); //taking integer input

        System.out.println("Enter Employee Salary:");
        salary = s.nextFloat(); //taking float input

        // Printing employee Details
        System.out.println("Employee  details:");
        System.out.println("Employee  name is: " +name);
        System.out.println("Employee  id is: " +id);
        System.out.println("Employee  salary is: " +salary);
        s.close();
    }
    }
